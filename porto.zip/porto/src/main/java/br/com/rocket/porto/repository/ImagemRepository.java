package br.com.rocket.porto.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import br.com.rocket.porto.model.Imagem;

public interface ImagemRepository extends MongoRepository<Imagem, String>, QuerydslPredicateExecutor<Imagem>	{

}
