package br.com.rocket.porto.service;

import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import br.com.rocket.porto.dto.DLApi;
import br.com.rocket.porto.dto.ImagemDTO;
import br.com.rocket.porto.model.Alerta;
import br.com.rocket.porto.repository.AlertaRepository;

@Service
public class ImagemService {
	
	static {
        disableSslVerification();
    }

    private static void disableSslVerification() {
        try{
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {

				@Override
				public void checkClientTrusted(X509Certificate[] arg0,
						String arg1) throws CertificateException {
				}

				@Override
				public void checkServerTrusted(X509Certificate[] arg0,
						String arg1) throws CertificateException {
				}

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
                
            }
            };

            // Install the all-trusting trust manager
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
				@Override
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}
            };

            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
    }
	
	@Autowired
	private AlertaRepository repository;
	
	public void save(ImagemDTO dto) throws UnsupportedEncodingException {
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		
		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		ByteArrayResource contentsAsResource = new ByteArrayResource(Base64.decodeBase64(dto.getImage())){
            @Override
            public String getFilename(){
                return "imagem.jpg";
            }
        };
		body.add("files", contentsAsResource);
		
		HttpEntity<MultiValueMap<String, Object>> requestEntity
		 = new HttpEntity<>(body, headers);
		 
		String serverUrl = "https://177.67.49.218/powerai-vision-ingram/api/dlapis/931bbb6c-d066-4d3a-ac17-193a8c9f7e0c";
		 
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<DLApi> response = restTemplate
		  .postForEntity(serverUrl, requestEntity, DLApi.class);
		
		DLApi dlApi = response.getBody();
		
		if (dlApi.getClassified() != null && dlApi.getClassified().getFire() != null) {
			Alerta alerta = new Alerta();
			alerta.setLatitude(dto.getLatitude());
			alerta.setLongitude(dto.getLongitude());
			repository.save(alerta);
		}
		
	}

}
