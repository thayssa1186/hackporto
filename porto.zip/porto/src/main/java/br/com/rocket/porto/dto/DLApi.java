package br.com.rocket.porto.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class DLApi {
	
	private String webAPIId;
	private String imageUrl;
	private String imageMd5;
	private String result;
	private Classified classified;
	
	public String getWebAPIId() {
		return webAPIId;
	}
	public void setWebAPIId(String webAPIId) {
		this.webAPIId = webAPIId;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getImageMd5() {
		return imageMd5;
	}
	public void setImageMd5(String imageMd5) {
		this.imageMd5 = imageMd5;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Classified getClassified() {
		return classified;
	}
	public void setClassified(Classified classified) {
		this.classified = classified;
	}

}
