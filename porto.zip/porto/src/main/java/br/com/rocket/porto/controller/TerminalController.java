package br.com.rocket.porto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.rocket.porto.service.LocalizacaoService;

@RestController
@RequestMapping("terminal")
public class TerminalController {

	@Autowired
	private LocalizacaoService service;
	
}
