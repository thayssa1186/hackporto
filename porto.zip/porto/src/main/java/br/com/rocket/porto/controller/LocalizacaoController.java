package br.com.rocket.porto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.rocket.porto.dto.LocalizacaoDTO;
import br.com.rocket.porto.model.Localizacao;
import br.com.rocket.porto.service.LocalizacaoService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("localizacao")
public class LocalizacaoController {

	@Autowired
	private LocalizacaoService service;
	
	@GetMapping
	public List<Localizacao> listarLocalizacao() {
		return service.listarLocalizacao();
	}
	
	@PostMapping
	public void criar(@RequestBody LocalizacaoDTO dto) {
		service.criar(dto);
	}
	
}
