package br.com.rocket.porto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.rocket.porto.model.Alerta;
import br.com.rocket.porto.service.AlertaService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("alerta")
public class AlertaController {

	@Autowired
	private AlertaService service;
	
	@GetMapping
	public List<Alerta> listarAlerta() {
		return service.listarAlerta();
	}
	
}
