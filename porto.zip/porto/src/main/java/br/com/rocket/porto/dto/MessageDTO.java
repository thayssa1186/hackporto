package br.com.rocket.porto.dto;

import java.util.List;

public class MessageDTO {
	
	private List<ImagemDTO> messages;
	
	public List<ImagemDTO> getMessages() {
		return messages;
	}
	
	public void setMessages(List<ImagemDTO> messages) {
		this.messages = messages;
	}

}
