package br.com.rocket.porto.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.rocket.porto.repository.TerminalRepository;

@Service
public class TerminalService {
	
	@Autowired
	private TerminalRepository repository;

}
