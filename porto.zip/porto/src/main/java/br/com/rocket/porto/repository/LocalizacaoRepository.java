package br.com.rocket.porto.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import br.com.rocket.porto.model.Localizacao;

public interface LocalizacaoRepository extends MongoRepository<Localizacao, String>, QuerydslPredicateExecutor<Localizacao>	{

}
