package br.com.rocket.porto.dto;

public class TerminalDTO {

}
