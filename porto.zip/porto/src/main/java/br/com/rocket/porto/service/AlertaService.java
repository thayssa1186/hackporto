package br.com.rocket.porto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.rocket.porto.model.Alerta;
import br.com.rocket.porto.repository.AlertaRepository;

@Service
public class AlertaService {
	
	@Autowired
	private AlertaRepository repository;

	public List<Alerta> listarAlerta() {
		return repository.findAll();
	}

}
