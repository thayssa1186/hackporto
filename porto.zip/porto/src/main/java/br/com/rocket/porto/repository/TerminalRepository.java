package br.com.rocket.porto.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import br.com.rocket.porto.model.Terminal;

public interface TerminalRepository extends MongoRepository<Terminal, String>, QuerydslPredicateExecutor<Terminal>	{

}
