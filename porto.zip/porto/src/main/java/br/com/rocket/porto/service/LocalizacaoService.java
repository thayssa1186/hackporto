package br.com.rocket.porto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.rocket.porto.dto.LocalizacaoDTO;
import br.com.rocket.porto.model.Localizacao;
import br.com.rocket.porto.repository.LocalizacaoRepository;

@Service
public class LocalizacaoService {
	
	@Autowired
	private LocalizacaoRepository repository;

	public List<Localizacao> listarLocalizacao() {
		return repository.findAll();
	}

	public void criar(LocalizacaoDTO dto) {
		Localizacao localizacao = new Localizacao();
		localizacao.setLatitude(dto.getLatitude());
		localizacao.setLongitude(dto.getLongitude());
		repository.save(localizacao);
	}

}
