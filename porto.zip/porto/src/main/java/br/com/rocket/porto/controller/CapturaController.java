package br.com.rocket.porto.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.rocket.porto.dto.ImagemDTO;
import br.com.rocket.porto.dto.MessageDTO;
import br.com.rocket.porto.service.ImagemService;

@RestController
@RequestMapping("captura")
public class CapturaController {
	
	@Autowired
	private ImagemService imagemService;

	@PostMapping
	public void captura(@RequestBody MessageDTO messageDTO) throws IOException {
		for (ImagemDTO imagemDTO: messageDTO.getMessages()) {
			imagemService.save(imagemDTO);
		}
	}
	
}
