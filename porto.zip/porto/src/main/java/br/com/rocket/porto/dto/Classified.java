package br.com.rocket.porto.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class Classified {
	
	private String _negative_;
	private String fire;
	
	public String get_negative_() {
		return _negative_;
	}
	public void set_negative_(String _negative_) {
		this._negative_ = _negative_;
	}
	public String getFire() {
		return fire;
	}
	public void setFire(String fire) {
		this.fire = fire;
	}
	
	

}
