import React, { Component } from 'react'
import ApiService from "../../service/ApiService.js";

class AddLocalizacaoComponent extends Component {

    constructor(props){
        super(props);
        this.state = {
            descricao: '',
            latitude: '',
            longitude: '',
            message: null
        }
        this.saveLocalizacao = this.saveLocalizacao.bind(this);
    }

    saveLocalizacao = (e) => {
        e.preventDefault();
        let localizacao = {descricao: this.state.descricao, latitude: this.state.latitude, longitude: this.state.longitude};
        ApiService.addLocalizacao(localizacao)
            .then(res => {
                this.setState({message : 'Localizacao adicionada com sucesso.'});
                this.props.history.push('/localizacao');
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return(
            <div>
                <h2 className="text-center">Adicionar Localização</h2>
                <form>
                <div className="form-group">
                    <label>Descrição:</label>
                    <input type="text" placeholder="descricao" name="descricao" className="form-control" value={this.state.descricao} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Latitude:</label>
                    <input type="text" placeholder="latitude" name="latitude" className="form-control" value={this.state.latitude} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Longitude:</label>
                    <input type="text" placeholder="longitude" name="longitude" className="form-control" value={this.state.longitude} onChange={this.onChange}/>
                </div>

                <button className="btn btn-success" onClick={this.saveLocalizacao}>Gravar</button>
            </form>
    </div>
        );
    }
}

export default AddLocalizacaoComponent;