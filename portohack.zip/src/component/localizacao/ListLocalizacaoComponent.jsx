import React, { Component } from 'react'
import ApiService from "../../service/ApiService.js";

class ListLocalizacaoComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            localizacoes: [],
            message: null
        }
        this.addLocalizacao = this.addLocalizacao.bind(this);
        this.reloadLocalizacaoList = this.reloadLocalizacaoList.bind(this);
    }

    componentDidMount() {
        this.reloadLocalizacaoList();
    }

    reloadLocalizacaoList() {
        ApiService.fetchLocalizacoes()
            .then((res) => {
                this.setState({localizacoes: res.data})
            });
    }

    addLocalizacao() {
        //window.localStorage.removeItem("localizacaoId");
        this.props.history.push('/add-localizacao');
    }

    render() {
        return (
            <div>
                <h2 className="text-center">User Details</h2>
                <button className="btn btn-danger" onClick={() => this.addLocalizacao()}> Adicionar</button>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Descrição</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.localizacoes && this.state.localizacoes.map(
                                localizacao =>
                                    <tr key={localizacao.id}>
                                        <td>{localizacao.descricao}</td>
                                        <td>{localizacao.latitude}</td>
                                        <td>{localizacao.longitude}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default ListLocalizacaoComponent;