import React, { Component } from 'react'
import ApiService from "../../service/ApiService.js";

class ListAlertaComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            alertas: [],
            message: null
        }
        this.reloadAlertaList = this.reloadAlertaList.bind(this);
    }

    componentDidMount() {
        this.reloadAlertaList();
    }

    reloadAlertaList() {
        ApiService.fetchAlertas()
            .then((res) => {
                this.setState({alertas: res.data})
            });
    }

    render() {
        return (
            <div>
                <h2 className="text-center">User Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.alertas && this.state.alertas.map(
                                alerta =>
                                    <tr key={alerta.id}>
                                        <td>{alerta.localizacao}</td>
                                        <td>{alerta.descricao}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default ListAlertaComponent;