import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import AddLocalizacaoComponent from "./component/localizacao/AddLocalizacaoComponent";
import ListLocalizacaoComponent from "./component/localizacao/ListLocalizacaoComponent";

function App() {
  return (
    <div className="container">
          <Router>
              <div className="col-md-6">
                  <h1 className="text-center" style={style}>44Pier</h1>
                  <Switch>
                      <Route path="/localizacao" component={ListLocalizacaoComponent} />
                      <Route path="/add-localizacao" component={AddLocalizacaoComponent} />
                  </Switch>
              </div>
          </Router>
      </div>
  );
}

const style = {
  color: 'red',
  margin: '10px'
}

export default App;
