import axios from 'axios';

const USER_API_BASE_URL = 'http://localhost:8080';

class ApiService {

    fetchLocalizacoes() {
        return axios.get(USER_API_BASE_URL + '/localizacao');
    }

    fetchAlertas() {
        return axios.get(USER_API_BASE_URL + '/alerta');
    }

    addLocalizacao(localizacao) {
        return axios.post(USER_API_BASE_URL + '/localizacao', localizacao);
    }

}

export default new ApiService();